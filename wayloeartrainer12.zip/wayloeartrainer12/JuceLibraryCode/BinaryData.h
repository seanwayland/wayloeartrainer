/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#pragma once

namespace BinaryData
{
    extern const char*   _36_mp3;
    const int            _36_mp3Size = 21924;

    extern const char*   _37_mp3;
    const int            _37_mp3Size = 21924;

    extern const char*   _38_mp3;
    const int            _38_mp3Size = 21924;

    extern const char*   _39_mp3;
    const int            _39_mp3Size = 21924;

    extern const char*   _40_mp3;
    const int            _40_mp3Size = 21924;

    extern const char*   _41_mp3;
    const int            _41_mp3Size = 21924;

    extern const char*   _42_mp3;
    const int            _42_mp3Size = 21924;

    extern const char*   _43_mp3;
    const int            _43_mp3Size = 21924;

    extern const char*   _44_mp3;
    const int            _44_mp3Size = 21924;

    extern const char*   _45_mp3;
    const int            _45_mp3Size = 21924;

    extern const char*   _46_mp3;
    const int            _46_mp3Size = 21924;

    extern const char*   _47_mp3;
    const int            _47_mp3Size = 21924;

    extern const char*   _48_mp3;
    const int            _48_mp3Size = 21924;

    extern const char*   _49_mp3;
    const int            _49_mp3Size = 21924;

    extern const char*   _50_mp3;
    const int            _50_mp3Size = 21924;

    extern const char*   _51_mp3;
    const int            _51_mp3Size = 21924;

    extern const char*   _52_mp3;
    const int            _52_mp3Size = 21924;

    extern const char*   _53_mp3;
    const int            _53_mp3Size = 21924;

    extern const char*   _54_mp3;
    const int            _54_mp3Size = 21924;

    extern const char*   _55_mp3;
    const int            _55_mp3Size = 21924;

    extern const char*   _56_mp3;
    const int            _56_mp3Size = 21924;

    extern const char*   _57_mp3;
    const int            _57_mp3Size = 21924;

    extern const char*   _58_mp3;
    const int            _58_mp3Size = 21924;

    extern const char*   _59_mp3;
    const int            _59_mp3Size = 21924;

    extern const char*   _60_mp3;
    const int            _60_mp3Size = 21924;

    extern const char*   _61_mp3;
    const int            _61_mp3Size = 21924;

    extern const char*   _62_mp3;
    const int            _62_mp3Size = 21924;

    extern const char*   _63_mp3;
    const int            _63_mp3Size = 21924;

    extern const char*   _64_mp3;
    const int            _64_mp3Size = 21924;

    extern const char*   _65_mp3;
    const int            _65_mp3Size = 21924;

    extern const char*   _66_mp3;
    const int            _66_mp3Size = 21924;

    extern const char*   _67_mp3;
    const int            _67_mp3Size = 21924;

    extern const char*   _68_mp3;
    const int            _68_mp3Size = 21924;

    extern const char*   _69_mp3;
    const int            _69_mp3Size = 21924;

    extern const char*   _70_mp3;
    const int            _70_mp3Size = 21924;

    extern const char*   _71_mp3;
    const int            _71_mp3Size = 21924;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Number of elements in the namedResourceList array.
    const int namedResourceListSize = 36;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}
