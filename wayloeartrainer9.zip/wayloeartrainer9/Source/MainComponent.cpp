#ifndef MAINCOMPONENT_H_INCLUDED
#define MAINCOMPONENT_H_INCLUDED

#include "../JuceLibraryCode/JuceHeader.h"
#include <random>
#include <iostream>
#include <vector>




class MainContentComponent   : public AudioAppComponent,
                               public ChangeListener,
                               public Button::Listener



{
public:
MainContentComponent()
:   state (Stopped)
{


        
        addAndMakeVisible (&playButton);
        playButton.setButtonText ("Play");
        playButton.addListener (this);
        playButton.setColour (TextButton::buttonColourId, Colours::green);
        playButton.setEnabled (true);

   
        setSize (300, 200);
        
        formatManager.registerBasicFormats();       // [1]
        transportSource.addChangeListener (this);   // [2]

        setAudioChannels (0, 2);
    }
    
    ~MainContentComponent()
    {
        shutdownAudio();
    }

    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override
    {
        transportSource.prepareToPlay (samplesPerBlockExpected, sampleRate);
    }

    void getNextAudioBlock (const AudioSourceChannelInfo& bufferToFill) override
    {
        if (readerSource == nullptr)
        {
            bufferToFill.clearActiveBufferRegion();
            return;
        }
        
        transportSource.getNextAudioBlock (bufferToFill);
    }

    void releaseResources() override
    {
        transportSource.releaseResources();
    }

    void resized() override
    {

        playButton.setBounds (10, 40, getWidth() - 20, 20);

    }
    
    void changeListenerCallback (ChangeBroadcaster* source) override
    {
        if (source == &transportSource)
        {
            if (transportSource.isPlaying())
                changeState (Playing);
            else
                changeState (Stopped);
        }
    }

    void buttonClicked (Button* button) override
    {

        if (button == &playButton)  playButtonClicked();

    }

private:
    enum TransportState
    {
        Initial,
        Stopped,
        Starting,
        Playing,
        Finished
    };
    void changeState (TransportState newState)
    {
        if (state != newState)
        {
            state = newState;
            switch (state)
            {
                case Initial:
                    transportSource.setPosition (0.0);
                    filesPlayed = 0;
                    break;
                case Stopped:
                    filesPlayed ++;
                    if (filesPlayed == 1)
                    {
                   int choice2 = Random::getSystemRandom().nextInt(35);
                   playfile(choice2);
                    }
                    break;
                case Starting:
                    playButton.setEnabled (true);
                    transportSource.start();
                    break;
                case Playing:
                    break;
                case Finished:
                    playButton.setEnabled (true);
                    transportSource.stop();
                    transportSource.setPosition (0.0);
                    break;
            }
        }
    }
    // edited version of play file demo
    // I have a bunch of mp3 files loaded as binary resources
    // I used the named resource[] to select them and play them in this method
    void playfile(int n)
    {
        AudioFormatReader* reader = formatManager.createReaderFor( new MemoryInputStream(BinaryData::getNamedResource(BinaryData::namedResourceList[n], mp3Size), mp3Size, false));
        if (reader != nullptr)
        {
            ScopedPointer<AudioFormatReaderSource> newSource = new AudioFormatReaderSource (reader, true);
            transportSource.setSource (newSource, 0, nullptr, reader->sampleRate);
            playButton.setEnabled (true);
            readerSource = newSource.release();
        }
        if (reader == nullptr)
        {
            playButton.setEnabled (false);
        }
        transportSource.setPosition (0.0);
        changeState (Starting);
    }
    // this code is what is crashing the plugin
    // ###THIS WOULD WORK #####
    // int choice2 = Random::getSystemRandom().nextInt(35);
    // playfile(choice2);
    // ### i am trying to replace it with this //
    void playButtonClicked()
    {
    // I am not sure where this for loop should be located and
     //   if the variables are correctly in scope
        for (int i=0; i < 11; i++)
        {
            if (numbers[i] == 1)
            {
                myvector.push_back(i);
            }
        }
    // select a random number and than grap an index from my vector
        int choice = Random::getSystemRandom().nextInt(4);
        int octavechoice = Random::getSystemRandom().nextInt(octaveRange);
        noteToPlay = choice + (octavechoice*12);
        int f = myvector.at(noteToPlay);
    
        playfile(f);
    }

    TextButton playButton;
    AudioFormatManager formatManager;
    ScopedPointer<AudioFormatReaderSource> readerSource;
    AudioTransportSource transportSource;
    TransportState state;
    char* note;
    char* newnote;

    int filesPlayed = 0;
    int f;
    int i;
    int octaveRange = 1;
    int noteToPlay;
    // size of each binary file is the same
    int mp3Size = 21924;
    // boolean array of available notes from chrom scale
    int numbers[12] = {0,1,1,0,0,1,1,0,0,1,0,0};
    // vector to contain notes
    std::vector<int> myvector;
 

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainContentComponent)
};


Component* createMainContentComponent()     { return new MainContentComponent(); }


#endif  // MAINCOMPONENT_H_INCLUDED
